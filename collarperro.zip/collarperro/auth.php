<?php
// ============================================================
//  auth.php — Configuración BD + funciones de sesión
//  Incluir con: require_once 'auth.php';
// ============================================================

define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_NAME', 'sensores_db');

function getDB() {
    $conn = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);
    if ($conn->connect_error) die(json_encode(["ok"=>false,"error"=>$conn->connect_error]));
    $conn->set_charset("utf8mb4");
    return $conn;
}

function startSession() {
    if (session_status() === PHP_SESSION_NONE) {
        session_set_cookie_params(['httponly'=>true, 'samesite'=>'Strict']);
        session_start();
    }
}

function requireLogin($rol = null) {
    startSession();
    if (empty($_SESSION['usuario_id'])) {
        header('Location: login.php'); exit;
    }
    if ($rol && $_SESSION['rol'] !== $rol) {
        header('Location: login.php?error=acceso'); exit;
    }
}

function usuarioActual() {
    startSession();
    return [
        'id'     => $_SESSION['usuario_id'] ?? null,
        'nombre' => $_SESSION['nombre']     ?? '',
        'rol'    => $_SESSION['rol']        ?? '',
        'email'  => $_SESSION['email']      ?? '',
    ];
}
